/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Laboratorio4.models;

/**
 *
 * @author Kenneth Rodriguez
 */
public class User {
    private String usuario;
    private String contrasena;
    private String email;
    private String nombre;
    private String apellidos;
    private String ocupacion;
    
    
    public User()
    {
        usuario="Kenneth";
        contrasena="Libres";
        email="kennethrodriguez3b@hotmail.com";
        nombre="Kenneth";
        apellidos="Rodriguez Pinto";
        ocupacion="Estudiante";
    }
    
    public String obtenerUsuario()
    {
        return usuario;
    }
    
    public String obtenerContrasena()
    {
        return contrasena;
    }
    public String toString()
    {
        return usuario + contrasena + email + nombre + apellidos + ocupacion;
    }
}
